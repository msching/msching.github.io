//
//  main.m
//  MediaLibraryExportThrowaway1
//
//  Created by Chris Adamson on 7/16/10.
//  http://www.subfurther.com/
//  Released into the public domain, 7/19/10
//

#import <UIKit/UIKit.h>

int main(int argc, char *argv[]) {
    
    NSAutoreleasePool * pool = [[NSAutoreleasePool alloc] init];
    int retVal = UIApplicationMain(argc, argv, nil, nil);
    [pool release];
    return retVal;
}
